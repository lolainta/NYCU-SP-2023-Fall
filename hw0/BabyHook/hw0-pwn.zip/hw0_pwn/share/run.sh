#!/bin/sh

cd /home/chal/
timeout 60 python3 main.py

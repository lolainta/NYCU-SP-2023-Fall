#include <stdio.h>
#include <unistd.h>

int main(void)
{
    sleep(0x48763);
    puts("You win!! Maybe :)");
    return 0;
}
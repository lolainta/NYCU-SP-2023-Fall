#include <stdio.h>


void addIntegers(int a, int b, int c, int d, int e, int f, int g) {
    printf("%d", a+b+c+d+e+f+g);
}

int main() {
    addIntegers(1, 2, 3, 4, 5, 6, 7);
    return 0;
}

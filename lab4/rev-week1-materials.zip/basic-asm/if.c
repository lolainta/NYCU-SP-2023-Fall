int main() {
    int a = 1;

    if (a < 2) {
        a = 2;
    }

    return 0;
}